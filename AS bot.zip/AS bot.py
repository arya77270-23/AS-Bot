import tkinter as tk
from tkinter import scrolledtext, messagebox
def get_bot_response(user_input):
    responses = {
        "hello": "Hi! How can I help you today?",
        "hi": "Hey! Nice to see you ",
        "how are you": "I'm just a chatbot, but I'm doing great! Thanks for asking.",
        "your name": "I'm AS Bot — your friendly chatbot ",
        "bye": "Goodbye! Have a wonderful day! ",
        "list" or "what is list":"A mutable, ordered sequence of elements. Elements can be added, removed, or modified after creation. Defined using square brackets []",
        "tuple"or"what is tuple":"Tuple: An immutable, ordered sequence of elements. Elements cannot be changed after creation. Defined using parentheses ().",
        "python"or"what is python": "Python is a versatile, high-level, and beginner-friendly programming language used for web development, data science, AI, and task automation",
        "set"or"what is set": "A set in Python is an unordered collection of unique elements. It is a mutable data type, meaning elements can be added or removed after creation.",
        "dictionary"or "what is dictionary":"Python dictionary is a data structure that stores the value in key: value pairs. Values in a dictionary can be of any data type and can be duplicated, whereas keys can't be repeated and must be immutable.",
        "class" or "what is class":"In Python, a class serves as a blueprint or a template for creating objects. It defines a new type of entity that encapsulates both data (attributes) and behavior (methods) into a single, logical unit.",
        "inheritance" or "What is inheritence":"Inheritance in Python is a fundamental concept in object-oriented programming (OOP) that allows a new class (child class or subclass) to derive properties and methods from an existing class (parent class, superclass, or base class). ",
        "method overriding" or "What is method overriding":"Method overriding in Python is a concept in object-oriented programming where a subclass provides its own specific implementation of a method that is already defined in its superclass.",
        "function" or "what is function":"In Python, a function is a block of organized, reusable code designed to perform a specific task. Functions promote code reusability, improve modularity, and make programs easier to understand and maintain. ",   
        "help": "You can try asking: 'hello', 'how are you', 'what is your name','list','tuple','python','set','dictionary','class','inheritance','method overriding',or'function'."
    }
    user_input = user_input.lower()
    for key in responses:
        if key in user_input:
            return responses[key]
    return "Hmm... I’m not sure how to answer that. Could you rephrase?"
def send_message(event=None):
    user_message = user_input_box.get().strip()
    if user_message == "":
        return
    chat_window.config(state=tk.NORMAL)
    chat_window.insert(tk.END, f"You: {user_message}\n", "user")
    bot_response = get_bot_response(user_message)
    chat_window.insert(tk.END, f"AS Bot: {bot_response}\n\n", "bot")
    chat_window.config(state=tk.DISABLED)
    user_input_box.delete(0, tk.END)
    chat_window.see(tk.END)
def on_closing():
    if messagebox.askokcancel("Exit", "Do you really want to quit the chatbot?"):
        root.destroy()
def open_chat_window():
    welcome_frame.pack_forget()
    chat_frame = tk.Frame(root, bg="#2E2E2E")
    chat_frame.pack(fill=tk.BOTH, expand=True)
    title_label = tk.Label(chat_frame, text="AS Bot Chat Window", font=("Arial Rounded MT Bold", 14),
                        bg="#2E2E2E", fg="#00FFB7")
    title_label.pack(pady=10)
    global chat_window
    chat_window = scrolledtext.ScrolledText(
        chat_frame,
        wrap=tk.WORD,
        state=tk.DISABLED,
        font=("Arial", 11),
        bg="#1E1E1E",
        fg="#FFFFFF",
        insertbackground="#FFFFFF"
    )
    chat_window.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
    chat_window.tag_config("user", foreground="#82C8DF", font=("Arial", 11, "bold"))
    chat_window.tag_config("bot", foreground="#7BF4CE", font=("Arial", 11))
    input_frame = tk.Frame(chat_frame, bg="#2E2E2E")
    input_frame.pack(padx=10, pady=10, fill=tk.X)
    global user_input_box
    user_input_box = tk.Entry(input_frame, font=("Arial", 12), bg="#3E3E3E",
                            fg="white", insertbackground="white")
    user_input_box.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)
    user_input_box.bind("<Return>", send_message)
    send_button = tk.Button(input_frame, text="Send", command=send_message,
                            bg="#0E4032", fg="White", font=("Arial", 11, "bold"))
    send_button.pack(side=tk.LEFT, padx=5)
    exit_button = tk.Button(input_frame, text="Exit", command=on_closing,
                            bg="#4E1515", fg="white", font=("Arial", 11, "bold"))
    exit_button.pack(side=tk.LEFT, padx=5)
root = tk.Tk()
root.title("AS Bot - Smart Chatbot")
root.geometry("450x550")
root.configure(bg="#2E2E2E")
root.protocol("WM_DELETE_WINDOW", on_closing)
welcome_frame = tk.Frame(root, bg="#2E2E2E")
welcome_frame.pack(fill=tk.BOTH, expand=True)
welcome_title = tk.Label(
    welcome_frame,
    text=" Welcome to AS Bot ",
    font=("Arial", 18),
    bg="#2E2E2E",
    fg="#00FFB7"
)
welcome_title.pack(pady=40)
welcome_msg = tk.Label(
    welcome_frame,
    text="I am your friendly and simple chatbot",
    font=("Arial", 12),
    bg="#2E2E2E",
    fg="#FFFFFF",
    justify="center"
)
welcome_msg.pack(pady=20)
start_button = tk.Button(
    welcome_frame,
    text="Start Chatbot",
    font=("Arial", 12, "bold"),
    bg="#00FFB7",
    fg="black",
    padx=20,
    pady=10,
    command=open_chat_window
)
start_button.pack(pady=30)
root.mainloop()
